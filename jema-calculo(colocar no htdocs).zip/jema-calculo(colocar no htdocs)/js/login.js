
const formulario = document.getElementById("formLogin");
const mensagem = document.getElementById("mensagem");

formulario.addEventListener("submit", async (event) => {
    event.preventDefault();

    const email = document.getElementById("email").value;
    const senha = document.getElementById("senha").value;

    try {
        const resposta = await fetch(
            "http://localhost:8081/api/usuarios/login",
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    email: email,
                    senha: senha
                })
            }
        );

        const dados = await resposta.json();

        if (!resposta.ok) {
            mensagem.innerHTML = `
                <div class="alert alert-danger">
                    E-mail ou senha incorretos.
                </div>
            `;
            return;
        }

        localStorage.setItem("token", dados.token);

        mensagem.innerHTML = `
            <div class="alert alert-success">
                Login realizado com sucesso!
            </div>
        `;

        setTimeout(() => {
            window.location.href = "index.html";
        }, 1000);

    } catch (erro) {
        mensagem.innerHTML = `
            <div class="alert alert-danger">
                Não foi possível conectar ao servidor.
            </div>
        `;

        console.error(erro);
    }
});
