
async function buscarProdutos() {
    const mensagem = document.getElementById("mensagem");
    const tabela = document.getElementById("tabelaProdutos");

    try {
        const resposta = await fetch("php/buscar_itens.php");

        if (!resposta.ok) {
            throw new Error("Erro ao consultar os produtos.");
        }

        const produtos = await resposta.json();

        if (!Array.isArray(produtos)) {
            throw new Error("A API não retornou uma lista de produtos.");
        }

        let pesoTotal = 0;
        let volumeTotal = 0;

        tabela.innerHTML = "";

        produtos.forEach(item => {
            const quantidade = Number(item.quantidade);
            const pesoUnitario = Number(item.pesoUnitario);

            const altura = Number(item.altura);
            const largura = Number(item.largura);
            const comprimento = Number(item.comprimento);

            const valores = [
                quantidade,
                pesoUnitario,
                altura,
                largura,
                comprimento
            ];

            if (
                valores.some(v => !Number.isFinite(v) || v < 0) ||
                quantidade <= 0
            ) {
                throw new Error("Produto com dados inválidos.");
            }

            const pesoItem = quantidade * pesoUnitario;

            // Dimensões em centímetros convertidas para m³.
            const volumeItem =
                quantidade * altura * largura * comprimento / 1000000;

            pesoTotal += pesoItem;
            volumeTotal += volumeItem;

            const linha = document.createElement("tr");

            const dados = [
                item.numeroNotaFiscal,
                item.nomeProduto,
                quantidade,
                pesoItem.toFixed(2) + " kg",
                volumeItem.toFixed(6) + " m³"
            ];

            dados.forEach(valor => {
                const celula = document.createElement("td");
                celula.textContent = valor;
                linha.appendChild(celula);
            });

            tabela.appendChild(linha);
        });

        document.getElementById("pesoTotal").textContent =
            pesoTotal.toFixed(2) + " kg";

        document.getElementById("volumeTotal").textContent =
            volumeTotal.toFixed(6) + " m³";

        mensagem.textContent = produtos.length
            ? "Produtos carregados com sucesso."
            : "Nenhum produto encontrado.";

        if (produtos.length > 0) {
            await buscarVeiculos(pesoTotal, volumeTotal);
        } else {
            document.getElementById("mensagemVeiculos").textContent =
                "Não há carga para calcular a indicação.";
        }

    } catch (erro) {
        mensagem.textContent = "Erro: " + erro.message;
        console.error(erro);
    }
}


async function buscarVeiculos(pesoTotal, volumeTotal) {
    const mensagem = document.getElementById("mensagemVeiculos");
    const resultado = document.getElementById("resultadoVeiculos");

    mensagem.textContent = "Consultando veículos...";
    resultado.innerHTML = "";

    try {
        const resposta = await fetch("php/buscar_veiculos.php");

        if (!resposta.ok) {
            throw new Error("Erro ao consultar os veículos.");
        }

        const veiculos = await resposta.json();

        if (!Array.isArray(veiculos)) {
            throw new Error("A API não retornou uma lista de veículos.");
        }

        const validos = veiculos.filter(v => {
            const peso = Number(v.capacidadePesoKg);
            const volume = Number(v.capacidadeVolumeM3);

            return (
                Number.isFinite(peso) &&
                Number.isFinite(volume) &&
                peso > 0 &&
                volume > 0
            );
        });

        const compativeis = validos.filter(v =>
            Number(v.capacidadePesoKg) >= pesoTotal &&
            Number(v.capacidadeVolumeM3) >= volumeTotal
        );

        // Menor capacidade de volume.
        // Em caso de empate, menor capacidade de peso.
        compativeis.sort((a, b) =>
            Number(a.capacidadeVolumeM3) -
            Number(b.capacidadeVolumeM3) ||
            Number(a.capacidadePesoKg) -
            Number(b.capacidadePesoKg)
        );

        if (compativeis.length === 0) {
            mensagem.textContent = validos.length === 0
                ? "Não existem veículos com capacidades válidas cadastradas."
                : "Nenhum caminhão possui capacidade suficiente.";

            return;
        }

        const melhor = compativeis[0];

        mensagem.textContent =
            "Encontramos " + compativeis.length +
            " caminhão(ões) compatível(is).";

        const percentualPeso =
            pesoTotal / Number(melhor.capacidadePesoKg) * 100;

        const percentualVolume =
            volumeTotal / Number(melhor.capacidadeVolumeM3) * 100;

        resultado.innerHTML = `
            <div class="veiculo recomendado">

                <span class="status compativel">
                    MELHOR OPÇÃO
                </span>

                <h3>${escaparHTML(melhor.nomeVeiculo)}</h3>

                <p class="detalhe">
                    Modelo: ${escaparHTML(melhor.modeloVeiculo || "-")}
                    <br>
                    Placa: ${escaparHTML(melhor.placa || "-")}
                    <br>
                    Tipo: ${escaparHTML(melhor.tipoVeiculo || "-")}
                </p>

                <p><strong>Capacidade de peso</strong></p>

                <p>
                    ${pesoTotal.toFixed(2)} /
                    ${Number(melhor.capacidadePesoKg).toLocaleString("pt-BR")}
                    kg (${percentualPeso.toFixed(2)}% utilizado)
                </p>

                <div class="barra">
                    <div class="progresso"
                        style="width:${percentualPeso}%">
                    </div>
                </div>

                <p><strong>Capacidade de volume</strong></p>

                <p>
                    ${volumeTotal.toFixed(6)} /
                    ${Number(melhor.capacidadeVolumeM3).toFixed(2)}
                    m³ (${percentualVolume.toFixed(2)}% utilizado)
                </p>

                <div class="barra">
                    <div class="progresso"
                        style="width:${percentualVolume}%">
                    </div>
                </div>

            </div>
        `;

    } catch (erro) {
        mensagem.textContent = "Erro: " + erro.message;
        console.error(erro);
    }
}


function escaparHTML(valor) {
    return String(valor).replace(/[&<>"']/g, caractere => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[caractere]);
}


// Inicialização da aplicação
buscarProdutos();
