
<?php

echo "PHP funcionando corretamente no JEMA!";

?>