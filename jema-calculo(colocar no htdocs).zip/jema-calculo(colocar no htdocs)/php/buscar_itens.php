
<?php

$url = "http://localhost:8081/api/itens-nota";

// Inicializa a requisição cURL
$ch = curl_init($url);

// Configura a requisição
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPGET => true,
    CURLOPT_TIMEOUT => 10
]);

// Executa a requisição
$resposta = curl_exec($ch);

// Verifica erros de comunicação
if ($resposta === false) {
    http_response_code(500);
    die("Erro na comunicação: " . curl_error($ch));
}

// Verifica o código HTTP
$status = curl_getinfo($ch, CURLINFO_HTTP_CODE);

curl_close($ch);

if ($status !== 200) {
    http_response_code($status);
    die("Erro ao consultar a API. Código HTTP: " . $status);
}

// Converte o JSON em array PHP
$itens = json_decode($resposta, true);

if (json_last_error() !== JSON_ERROR_NONE) {
    http_response_code(500);
    die("Erro ao interpretar o JSON.");
}

// Retorna os dados
header("Content-Type: application/json; charset=UTF-8");

echo json_encode(
    $itens,
    JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT
);

?>
