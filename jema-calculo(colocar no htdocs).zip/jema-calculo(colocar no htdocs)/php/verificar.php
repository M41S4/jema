<?php

if (function_exists('curl_init')) {
    echo "cURL habilitado com sucesso!";
} else {
    echo "cURL ainda não está habilitado.";
}

?>