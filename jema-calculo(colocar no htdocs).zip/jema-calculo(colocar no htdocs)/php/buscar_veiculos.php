
<?php

header('Content-Type: application/json; charset=utf-8');

$url = "http://localhost:8081/api/veiculos";

$ch = curl_init($url);

curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);

$resposta = curl_exec($ch);

if ($resposta === false) {
    http_response_code(500);
    echo json_encode([
        "erro" => curl_error($ch)
    ]);
    curl_close($ch);
    exit;
}

$status = curl_getinfo($ch, CURLINFO_HTTP_CODE);

curl_close($ch);

http_response_code($status);
echo $resposta;
